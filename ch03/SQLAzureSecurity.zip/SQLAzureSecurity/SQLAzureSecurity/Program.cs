﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.Data.SqlClient;
using System.IO;
using System.Security.Cryptography.X509Certificates;

namespace BlueSyntax.SQLAzureSecurity
{

    public static class Entensions
    {
        public static byte[] GetBytes(this string value)
        {
            byte[] buffer = UTF8Encoding.UTF8.GetBytes(value);
            return buffer;
        }

        public static byte[] GetBytes(this DateTime value)
        {
            return value.ToString().GetBytes();
        }
    }

    public class Util
    {
        /// <summary>
        /// Computes a hash value based on an array of byte arrays
        /// </summary>
        /// <param name="bytes">Array of byte arrays</param>
        public static byte[] ComputeHash(params byte[][] bytes)
        {
            SHA256 sha = SHA256Managed.Create();
            MemoryStream ms = new MemoryStream();

            for (int i = 0; i < bytes.Length; i++)
                ms.Write(bytes[i], 0, bytes[i].Length);

            ms.Flush();
            ms.Position = 0;

            return sha.ComputeHash(ms);
        }
    }


    /// <summary>
    /// A result structure that stores the encrypted value 
    /// and its associated vector
    /// </summary>
    public struct CipherText
    {
        public byte[] cipher;
        public byte[] vector;
    }

    /// <summary>
    /// The encryption class that encapsulates the complexity behind encrypting 
    /// and decrypting values
    /// </summary>
    public class Encryption
    {

        #region _secret_key_ variable
        private byte[] _SECRET_KEY_ = new byte[] { 160, 225, 229, 3, 
            148, 219, 67, 89, 247, 133, 213, 26, 129, 160, 235, 41, 
            42, 177, 202, 251, 38, 56, 232, 90, 54, 88, 158, 169, 
            200, 24, 19, 27 };
        #endregion
        
        private string _THUMBPRINT_ = "01 71 11 17 0a b4 96 7b ca 1f f3 e5 bc 0f 68 9d c6 c0 3b 7b";

        /// <summary>
        /// Encrypts a string value using a self-signed certificate
        /// </summary>
        /// <param name="value">The value to encrypt</param>
        /// <returns></returns>
        public CipherText EncryptByCert(string value)
        {
            byte[] buffer = UTF8Encoding.UTF8.GetBytes(value);
            
            X509Store store = new X509Store(StoreName.Root, 
                StoreLocation.LocalMachine);
            store.Open(OpenFlags.ReadOnly);
            
            X509Certificate2 x509 = 
                store.Certificates.Find(
                X509FindType.FindByThumbprint,
                _THUMBPRINT_, true)[0];
            
            store.Close();

            RSACryptoServiceProvider rsaEncrypt = null;
            rsaEncrypt = (RSACryptoServiceProvider)x509.PublicKey.Key;

            byte[] encryptedBytes = rsaEncrypt.Encrypt(buffer, false);

            CipherText ct = new CipherText();
            ct.cipher = encryptedBytes;
            ct.vector = new byte[] {0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0};

            return ct;
        }

        public string DecryptByCert(CipherText ct)
        {
            X509Store store = new X509Store(StoreName.Root,
                StoreLocation.LocalMachine);
            store.Open(OpenFlags.ReadOnly);

            X509Certificate2 x509 =
                store.Certificates.Find(
                X509FindType.FindByThumbprint,
                _THUMBPRINT_, true)[0];

            store.Close();

            RSACryptoServiceProvider rsaEncrypt = null;
            rsaEncrypt = (RSACryptoServiceProvider)x509.PrivateKey;

            byte[] bytes = rsaEncrypt.Decrypt(ct.cipher, false);

            return UTF8Encoding.UTF8.GetString(bytes);
        }


        /// <summary>
        /// Encrypt using AES
        /// </summary>
        /// <param name="value">The string to encrypt</param>
        public CipherText EncryptAES(string value)
        {
            // Prepare variables...
            byte[] buffer = UTF8Encoding.UTF8.GetBytes(value);
            CipherText ct = new CipherText();
            System.Security.Cryptography.Aes aes = null;
            ICryptoTransform transform = null;

            // Create the AES object
            aes = System.Security.Cryptography.Aes.Create();
            aes.GenerateIV();
            aes.Key = _SECRET_KEY_;

            // Create the encryption object
            transform = aes.CreateEncryptor();
            
            // Encrypt and store the result in the structure
            ct.cipher = transform.TransformFinalBlock(buffer, 0, buffer.Length);
            // Save the vector used for future use
            ct.vector = aes.IV;

            return ct;
        }

        public string DecryptAES(CipherText ct)
        {
            // Prepare variables...
            System.Security.Cryptography.Aes aes = null;
            ICryptoTransform transform = null;

            // Create the AES object
            aes = System.Security.Cryptography.Aes.Create();
            aes.IV = ct.vector;
            aes.Key = _SECRET_KEY_;

            // Create the decryption object
            transform = aes.CreateDecryptor();

            // Encrypt and store the result in the structure
            byte[] buffer = transform.TransformFinalBlock(ct.cipher, 0, ct.cipher.Length);
            string value = UTF8Encoding.UTF8.GetString(buffer);
            
            return value;
        }

    }

    public class UserProperties
    {

        /// <summary>
        /// Saves a property value in a SQL Azure database
        /// </summary>
        /// <param name="propertyName">The property name</param>
        /// <param name="ct">The CipherText structure to save</param>
        public static void Save(string propertyName, CipherText ct)
        {
            using (SqlConnection sqlConn = new SqlConnection(CDatabase.ConnectionString))
            {
                sqlConn.Open();

                using (SqlCommand sqlCmd = new SqlCommand())
                {

                    DateTime dateUpdated = DateTime.Now;

                    sqlCmd.Connection = sqlConn;
                    sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                    sqlCmd.CommandText = "proc_SaveProperty";
                    sqlCmd.Parameters.Add("name", System.Data.SqlDbType.NVarChar, 255);
                    sqlCmd.Parameters.Add("value", System.Data.SqlDbType.VarBinary, int.MaxValue);
                    sqlCmd.Parameters.Add("vector", System.Data.SqlDbType.Binary, 16);
                    sqlCmd.Parameters.Add("lastUpdated", System.Data.SqlDbType.DateTime);
                    sqlCmd.Parameters.Add("hash", System.Data.SqlDbType.Binary, 32);
                    sqlCmd.Parameters[0].Value = propertyName;
                    sqlCmd.Parameters[1].Value = ct.cipher;
                    sqlCmd.Parameters[2].Value = ct.vector;
                    sqlCmd.Parameters[3].Value = dateUpdated;

                    // Calculate the hash of this record...
                    // We pass the list of values that should be hashed
                    // If any of these values changes in the database,
                    // recalculating the hash would yield a different result
                    byte[] hash = Util.ComputeHash(
                        propertyName.GetBytes(),
                        ct.cipher,
                        ct.vector,
                        dateUpdated.GetBytes());
                    
                    sqlCmd.Parameters[4].Value = hash;

                    int res = sqlCmd.ExecuteNonQuery();

                }

                sqlConn.Close();

            }
        }



    }

    class Program
    {
        static void Main(string[] args)
        {
            // Declare the encryption object and encrypt our secret value
            Encryption e = new Encryption();
            CipherText ct = e.EncryptAES("secret value goes here...");
            CipherText ct2 = e.EncryptByCert("another secret!!!");

            string s = e.DecryptByCert(ct2);

            UserProperties.Save("MySecret", ct);
            UserProperties.Save("MySecret2", ct2); 


        }
    }
}
