﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BlueSyntax.SQLAzureSecurity
{
    internal class CDatabase
    {

        internal static string ConnectionString
        {
            get
            {
                return "Server=tcp:{SERVER}.database.windows.net;Database=EnzoLog;User ID={UID};Password={PWD};Trusted_Connection=False;";
            }
        }

    }
}
